# Exemplos - Guia de Implementação do Resultado de Exame Laboratorial (REL) da RNDS v1.0.0

## Exemplos

### Exemplos do REL

 
* [Bundle de exemplo do REL com exame do GAL](Bundle-example-bundle-rel-gal.md)
* [Bundle de exemplo do REL com exame em LOINC](Bundle-example-bundle-rel-loinc.md)
 

