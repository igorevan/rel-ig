# Resultado Qualitativo do Exame 2.0 (ValueSet) - Guia de Implementação do Resultado de Exame Laboratorial (REL) da RNDS v1.0.0-release

## ValueSet: Resultado Qualitativo do Exame 2.0 (ValueSet) 

 **References** 

* [Diagnóstico em Laboratório Clínico](StructureDefinition-BRDiagnosticoLaboratorioClinico-3.2.1.md)

### Definição lógica (CLD)

 

### Expansão

-------

 [Descrição do(s) quadro(s) acima](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BRResultadoQualitativoExame-2.0",
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/rel/ImplementationGuide/br.gov.saude.rel.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/rel/ImplementationGuide/br.gov.saude.rel.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRResultadoQualitativoExame-2.0",
  "version" : "1.0.0-release",
  "name" : "BRResultadoQualitativoExame",
  "title" : "Resultado Qualitativo do Exame 2.0 (ValueSet)",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-03-26T13:21:38.6543319+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "ValueSet utilizado para definir o valor atribuído ao resultado de um exame laboratorial realizado por método de análise qualitativo.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "immutable" : false,
  "compose" : {
    "include" : [{
      "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRResultadoQualitativoExame"
    },
    {
      "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoResultadoAVIDEZ"
    },
    {
      "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoResultadoDTNT"
    },
    {
      "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoResultadoHISPT"
    },
    {
      "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoResultadoPRAU"
    },
    {
      "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoResultadoPSNG"
    },
    {
      "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoResultadoRGNR"
    },
    {
      "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoResultadoRSBAC"
    },
    {
      "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRTipoResultadoRSCUL"
    }]
  }
}

```
