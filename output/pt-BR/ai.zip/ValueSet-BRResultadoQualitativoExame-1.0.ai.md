# Resultado Qualitativo do Exame 1.0 (ValueSet) - Guia de Implementação do Resultado de Exame Laboratorial (REL) da RNDS v1.0.0

## ValueSet: Resultado Qualitativo do Exame 1.0 (ValueSet) 

 **References** 

* [Diagnóstico em Laboratório Clínico](StructureDefinition-BRDiagnosticoLaboratorioClinico-3.2.1.md)

### Definição lógica (CLD)

 

### Expansão

-------

 [Descrição do(s) quadro(s) acima](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BRResultadoQualitativoExame-1.0",
  "language" : "pt-BR",
  "url" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRResultadoQualitativoExame-1.0",
  "version" : "1.0.0",
  "name" : "BRResultadoQualitativoExame",
  "title" : "Resultado Qualitativo do Exame 1.0 (ValueSet)",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-03-26T13:21:38.6543319+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "ValueSet utilizado para definir o valor atribuído ao resultado de um exame laboratorial realizado por método de análise qualitativo.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "immutable" : false,
  "compose" : {
    "include" : [{
      "system" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRResultadoQualitativoExame"
    }]
  }
}

```
