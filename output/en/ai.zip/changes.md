# Histórico de mudanças - Guia de Implementação do Resultado de Exame Laboratorial (REL) da RNDS v1.0.0-release

## Histórico de mudanças

 Lista de mudanças na especificação do IG desde a sua versão inicial: 

 **2026-06-10: REL IG v1.0.0-release** baseado no FHIR versão R4. 

* Versão inicial

