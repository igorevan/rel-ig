# Exames do GAL - Guia de Implementação do Resultado de Exame Laboratorial (REL) da RNDS v1.0.0-release

## CodeSystem: Exames do GAL 

This Code system is referenced in the definition of the following value sets:

* [Nome do Exame](ValueSet-BRNomeExame-2.0.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRNomeExameGAL",
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/rel/ImplementationGuide/br.gov.saude.rel.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/rel/ImplementationGuide/br.gov.saude.rel.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRNomeExameGAL",
  "version" : "1.0.0-release",
  "name" : "BRNomeExameGAL",
  "title" : "Exames do GAL",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-05-05T11:53:58.0082379+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Classifica o exame laboratorial realizado em amostra biológica para diagnóstico laboratorial, de acordo com o Gerenciador de Ambiente Laboratorial (GAL).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "coronavirusnCoV",
    "display" : "Novo coronavírus (2019-nCoV)"
  },
  {
    "code" : "COVID",
    "display" : "COVID-19, Biologia Molecular"
  },
  {
    "code" : "CVIDGG",
    "display" : "COVID-19, IgG"
  },
  {
    "code" : "CVIDGM",
    "display" : "COVID-19, IgM"
  },
  {
    "code" : "CHIKBM",
    "display" : "CHIKUNGUNYA, BIOLOGIA MOLECULAR"
  },
  {
    "code" : "CHIKG",
    "display" : "CHIKUNGUNYA, IGG"
  },
  {
    "code" : "CHIKM",
    "display" : "CHIKUNGUNYA, IGM"
  },
  {
    "code" : "CHIKTR",
    "display" : "CHIKUNGUNYA, TESTE RAPIDO IGM"
  },
  {
    "code" : "DENGG",
    "display" : "DENGUE IGG"
  },
  {
    "code" : "DENGM",
    "display" : "DENGUE IGM"
  },
  {
    "code" : "DENGMS",
    "display" : "DENGUE IGM SOROLOGIA"
  },
  {
    "code" : "DENGTR",
    "display" : "DENGUE TESTE RAPIDO"
  },
  {
    "code" : "DENAN",
    "display" : "DENGUE, DETECCAO DE ANTIGENO NS1"
  },
  {
    "code" : "FEAMB",
    "display" : "FEBRE AMARELA BIOLOGIA MOLECULAR"
  },
  {
    "code" : "FEAMM",
    "display" : "FEBRE AMARELA IGM"
  },
  {
    "code" : "FAEAPV",
    "display" : "FEBRE AMARELA, EVENTO ADVERSO POS VACINAL/EAPV"
  },
  {
    "code" : "FEAMG",
    "display" : "FEBRE AMARELA, IGG"
  },
  {
    "code" : "FAIMIG",
    "display" : "FEBRE AMARELA, TESTE RAPIDO IGM/IGG"
  },
  {
    "code" : "PEQARB",
    "display" : "PESQUISA DE ARBOVIRUS"
  },
  {
    "code" : "PEQZDC",
    "display" : "PESQUSA DE ARBOVIRUS (ZDC)"
  },
  {
    "code" : "ZIKABM",
    "display" : "ZIKA BIOLOGIA MOLECULAR"
  },
  {
    "code" : "ZIKAGG",
    "display" : "ZIKA IGG"
  },
  {
    "code" : "ZIKAGM",
    "display" : "ZIKA IGM"
  },
  {
    "code" : "ZIKATR",
    "display" : "ZIKA TESTE RAPIDO IGG E IGM"
  },
  {
    "code" : "FENLB",
    "display" : "Febre do Nilo Ocidental, Biologia Molecular"
  },
  {
    "code" : "FENLG",
    "display" : "Febre do Nilo Ocidental, IgG"
  },
  {
    "code" : "FENLM",
    "display" : "Febre do Nilo Ocidental, IgM"
  },
  {
    "code" : "MAYBIO",
    "display" : "Mayaro, Biologia Molecular"
  },
  {
    "code" : "MAYIGG",
    "display" : "Mayaro, IgG"
  },
  {
    "code" : "MAYIGM",
    "display" : "Mayaro, IgM"
  },
  {
    "code" : "OROBIO",
    "display" : "Oropouche, Biologia Molecular"
  },
  {
    "code" : "OROIGG",
    "display" : "Oropouche, IgG"
  },
  {
    "code" : "OROIGM",
    "display" : "Oropouche, IgM"
  },
  {
    "code" : "DENGB",
    "display" : "DENGUE, BIOLOGIA MOLECULAR"
  },
  {
    "code" : "INFSAZ",
    "display" : "Influenza"
  },
  {
    "code" : "RUBBM",
    "display" : "Rubéola, Biologia Molecular"
  },
  {
    "code" : "RUBG",
    "display" : "Rubéola, IgG"
  },
  {
    "code" : "RUBM",
    "display" : "Rubéola, IgM"
  },
  {
    "code" : "SARBM",
    "display" : "Sarampo, Biologia Molecular"
  },
  {
    "code" : "SARG",
    "display" : "Sarampo, IgG"
  },
  {
    "code" : "SARM",
    "display" : "Sarampo, IgM"
  },
  {
    "code" : "VARBIO",
    "display" : "Varicela, Biologia Molecular"
  },
  {
    "code" : "VARIG",
    "display" : "Varicela, IgG"
  },
  {
    "code" : "VARIM",
    "display" : "Varicela, IgM"
  },
  {
    "code" : "VARIOL",
    "display" : "Varíola"
  },
  {
    "code" : "VARZOS",
    "display" : "Varicela Zoster, Biologia Molecular"
  },
  {
    "code" : "VRSRT",
    "display" : "Vírus Respiratórios"
  }]
}

```
