# Subgrupo da Tabela SUS - Guia de Implementação do Resultado de Exame Laboratorial (REL) da RNDS v1.0.0-release

## CodeSystem: Subgrupo da Tabela SUS 

 
O subgrupo é o segundo nível da hierarquia da Tabela SUS e seus códigos ajudam a classificar e localizar procedimentos. 

This Code system is referenced in the definition of the following value sets:

* [Categoria do Exame](ValueSet-BRCategoriaExame-1.0.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRSubgrupoTabelaSUS",
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/rel/ImplementationGuide/br.gov.saude.rel.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/rel/ImplementationGuide/br.gov.saude.rel.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRSubgrupoTabelaSUS",
  "version" : "1.0.0-release",
  "name" : "BRSubgrupoTabelaSUS",
  "title" : "Subgrupo da Tabela SUS",
  "status" : "active",
  "experimental" : false,
  "date" : "2022-10-07T17:23:44.666897+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "O subgrupo é o segundo nível da hierarquia da Tabela SUS e seus códigos ajudam a classificar e localizar procedimentos.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "property" : [{
    "code" : "group",
    "type" : "string"
  }],
  "concept" : [{
    "code" : "0101",
    "display" : "Ações coletivas/individuais em saúde",
    "property" : [{
      "code" : "group",
      "valueString" : "01"
    }]
  },
  {
    "code" : "0102",
    "display" : "Vigilância em saúde",
    "property" : [{
      "code" : "group",
      "valueString" : "01"
    }]
  },
  {
    "code" : "0201",
    "display" : "Coleta de material",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0202",
    "display" : "Diagnóstico em laboratório clínico",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0203",
    "display" : "Diagnóstico por anatomia patológica e citopatologia",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0204",
    "display" : "Diagnóstico por radiologia",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0205",
    "display" : "Diagnóstico por ultrasonografia",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0206",
    "display" : "Diagnóstico por tomografia",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0207",
    "display" : "Diagnóstico por ressonância magnética",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0208",
    "display" : "Diagnóstico por medicina nuclear in vivo",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0209",
    "display" : "Diagnóstico por endoscopia",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0210",
    "display" : "Diagnóstico por radiologia intervencionista",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0211",
    "display" : "Métodos diagnósticos em especialidades",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0212",
    "display" : "Diagnóstico e procedimentos especiais em hemoterapia",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0213",
    "display" : "Diagnóstico em vigilância epidemiológica e ambiental",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0214",
    "display" : "Diagnóstico por teste rápido",
    "property" : [{
      "code" : "group",
      "valueString" : "02"
    }]
  },
  {
    "code" : "0301",
    "display" : "Consultas / Atendimentos / Acompanhamentos",
    "property" : [{
      "code" : "group",
      "valueString" : "03"
    }]
  },
  {
    "code" : "0302",
    "display" : "Fisioterapia",
    "property" : [{
      "code" : "group",
      "valueString" : "03"
    }]
  },
  {
    "code" : "0303",
    "display" : "Tratamentos clínicos (outras especialidades)",
    "property" : [{
      "code" : "group",
      "valueString" : "03"
    }]
  },
  {
    "code" : "0304",
    "display" : "Tratamento em oncologia",
    "property" : [{
      "code" : "group",
      "valueString" : "03"
    }]
  },
  {
    "code" : "0305",
    "display" : "Tratamento em nefrologia",
    "property" : [{
      "code" : "group",
      "valueString" : "03"
    }]
  },
  {
    "code" : "0306",
    "display" : "Hemoterapia",
    "property" : [{
      "code" : "group",
      "valueString" : "03"
    }]
  },
  {
    "code" : "0307",
    "display" : "Tratamentos odontológicos",
    "property" : [{
      "code" : "group",
      "valueString" : "03"
    }]
  },
  {
    "code" : "0308",
    "display" : "Tratamento de lesões, envenenamentos e outros, decorrentes de causas externas",
    "property" : [{
      "code" : "group",
      "valueString" : "03"
    }]
  },
  {
    "code" : "0309",
    "display" : "Terapias especializadas",
    "property" : [{
      "code" : "group",
      "valueString" : "03"
    }]
  },
  {
    "code" : "0310",
    "display" : "Parto e nascimento",
    "property" : [{
      "code" : "group",
      "valueString" : "03"
    }]
  },
  {
    "code" : "0311",
    "display" : "Cuidados Paliativos",
    "property" : [{
      "code" : "group",
      "valueString" : "03"
    }]
  },
  {
    "code" : "0401",
    "display" : "Pequenas cirurgias e cirurgias de pele, tecido subcutâneo e mucosa",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0402",
    "display" : "Cirurgia de glândulas endócrinas",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0403",
    "display" : "Cirurgia do sistema nervoso central e periférico",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0404",
    "display" : "Cirurgia das vias aéreas superiores, da face, da cabeça e do pescoço",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0405",
    "display" : "Cirurgia do aparelho da visão",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0406",
    "display" : "Cirurgia do aparelho circulatório",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0407",
    "display" : "Cirurgia do aparelho digestivo, orgãos anexos e parede abdominal",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0408",
    "display" : "Cirurgia do sistema osteomuscular",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0409",
    "display" : "Cirurgia do aparelho geniturinário",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0410",
    "display" : "Cirurgia de mama",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0411",
    "display" : "Cirurgia obstétrica",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0412",
    "display" : "Cirurgia torácica",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0413",
    "display" : "Cirurgia reparadora",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0414",
    "display" : "Bucomaxilofacial",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0415",
    "display" : "Outras cirurgias",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0416",
    "display" : "Cirurgia em oncologia",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0417",
    "display" : "Anestesiologia",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0418",
    "display" : "Cirurgia em nefrologia",
    "property" : [{
      "code" : "group",
      "valueString" : "04"
    }]
  },
  {
    "code" : "0501",
    "display" : "Coleta e exames para fins de doação de orgãos, tecidos e células e de transplante",
    "property" : [{
      "code" : "group",
      "valueString" : "05"
    }]
  },
  {
    "code" : "0502",
    "display" : "Avaliação de morte encefálica",
    "property" : [{
      "code" : "group",
      "valueString" : "05"
    }]
  },
  {
    "code" : "0503",
    "display" : "Ações relacionadas à doação de orgãos e tecidos para transplante",
    "property" : [{
      "code" : "group",
      "valueString" : "05"
    }]
  },
  {
    "code" : "0504",
    "display" : "Processamento de tecidos para transplante",
    "property" : [{
      "code" : "group",
      "valueString" : "05"
    }]
  },
  {
    "code" : "0505",
    "display" : "Transplante de orgãos, tecidos e células",
    "property" : [{
      "code" : "group",
      "valueString" : "05"
    }]
  },
  {
    "code" : "0506",
    "display" : "Acompanhamento e intercorrências no pré e pós-transplante",
    "property" : [{
      "code" : "group",
      "valueString" : "05"
    }]
  },
  {
    "code" : "0601",
    "display" : "Medicamentos de dispensação excepcional",
    "property" : [{
      "code" : "group",
      "valueString" : "06"
    }]
  },
  {
    "code" : "0602",
    "display" : "Medicamentos estratégicos",
    "property" : [{
      "code" : "group",
      "valueString" : "06"
    }]
  },
  {
    "code" : "0603",
    "display" : "Medicamentos de âmbito hospitalar e urgência",
    "property" : [{
      "code" : "group",
      "valueString" : "06"
    }]
  },
  {
    "code" : "0604",
    "display" : "Componente Especializado da Assitencia Farmaceutica",
    "property" : [{
      "code" : "group",
      "valueString" : "06"
    }]
  },
  {
    "code" : "0701",
    "display" : "Órteses, próteses e materiais especiais não relacionados ao ato cirúrgico",
    "property" : [{
      "code" : "group",
      "valueString" : "07"
    }]
  },
  {
    "code" : "0702",
    "display" : "Órteses, próteses e materiais especiais relacionados ao ato cirúrgico",
    "property" : [{
      "code" : "group",
      "valueString" : "07"
    }]
  },
  {
    "code" : "0801",
    "display" : "Ações relacionadas ao estabelecimento",
    "property" : [{
      "code" : "group",
      "valueString" : "08"
    }]
  },
  {
    "code" : "0802",
    "display" : "Ações relacionadas ao atendimento",
    "property" : [{
      "code" : "group",
      "valueString" : "08"
    }]
  },
  {
    "code" : "0803",
    "display" : "Autorização / Regulação",
    "property" : [{
      "code" : "group",
      "valueString" : "08"
    }]
  },
  {
    "code" : "0804",
    "display" : "Telessaúde",
    "property" : [{
      "code" : "group",
      "valueString" : "08"
    }]
  },
  {
    "code" : "0901",
    "display" : "Atenção em Oncologia e a Forma de Organização",
    "property" : [{
      "code" : "group",
      "valueString" : "09"
    }]
  },
  {
    "code" : "0902",
    "display" : "Atenção em Cardiologia",
    "property" : [{
      "code" : "group",
      "valueString" : "09"
    }]
  },
  {
    "code" : "0903",
    "display" : "Atenção em Ortopedia",
    "property" : [{
      "code" : "group",
      "valueString" : "09"
    }]
  },
  {
    "code" : "0904",
    "display" : "Atenção em Otorrinolaringologia",
    "property" : [{
      "code" : "group",
      "valueString" : "09"
    }]
  },
  {
    "code" : "0905",
    "display" : "Atenção em Oftalmologia",
    "property" : [{
      "code" : "group",
      "valueString" : "09"
    }]
  }]
}

```
