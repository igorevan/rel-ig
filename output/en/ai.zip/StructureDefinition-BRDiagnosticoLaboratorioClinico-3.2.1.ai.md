# Diagnóstico em Laboratório Clínico - Guia de Implementação do Resultado de Exame Laboratorial (REL) da RNDS v1.0.0-release

## Resource Profile: Diagnóstico em Laboratório Clínico 

**Usos:**

* Refere a este Perfil: [Condição de Saúde](StructureDefinition-BRCondicaoSaude.md) and [Resultado de Exame Laboratorial](StructureDefinition-BRResultadoExameLaboratorial-3.2.1.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/br.gov.saude.rel.fhir|current/StructureDefinition/StructureDefinition-BRDiagnosticoLaboratorioClinico-3.2.1.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-BRDiagnosticoLaboratorioClinico-3.2.1.csv), [Excel](../StructureDefinition-BRDiagnosticoLaboratorioClinico-3.2.1.xlsx), [Schematron](../StructureDefinition-BRDiagnosticoLaboratorioClinico-3.2.1.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "BRDiagnosticoLaboratorioClinico-3.2.1",
  "meta" : {
    "lastUpdated" : "2022-10-10T21:33:32.3996294+00:00"
  },
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/rel/ImplementationGuide/br.gov.saude.rel.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/rel/ImplementationGuide/br.gov.saude.rel.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRDiagnosticoLaboratorioClinico-3.2.1",
  "version" : "1.0.0-release",
  "name" : "BRDiagnosticoLaboratorioClinico",
  "title" : "Diagnóstico em Laboratório Clínico",
  "status" : "active",
  "date" : "2021-04-12",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Exame ou teste realizado em laboratório com finalidade diagnóstica ou investigativa.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Observation",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Observation",
      "path" : "Observation",
      "definition" : "Exame ou teste realizado em laboratório com finalidade diagnóstica ou investigativa.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.extension",
      "path" : "Observation.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "rules" : "open"
      },
      "min" : 0
    },
    {
      "id" : "Observation.extension:pathogen",
      "path" : "Observation.extension",
      "sliceName" : "pathogen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRPatogeno"]
      }],
      "isModifier" : false
    },
    {
      "id" : "Observation.identifier",
      "path" : "Observation.identifier",
      "max" : "0"
    },
    {
      "id" : "Observation.basedOn",
      "path" : "Observation.basedOn",
      "max" : "0"
    },
    {
      "id" : "Observation.partOf",
      "path" : "Observation.partOf",
      "max" : "0"
    },
    {
      "id" : "Observation.status",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.status",
      "short" : "Estado da Observação",
      "definition" : "O estado do valor do resultado.",
      "binding" : {
        "strength" : "required",
        "description" : "Estado da Observação",
        "valueSet" : "http://www.saude.gov.br/fhir/r4/ValueSet/BREstadoObservacao-1.0"
      }
    },
    {
      "id" : "Observation.category",
      "path" : "Observation.category",
      "short" : "Categoria do Exame",
      "definition" : "Categoriza o exame ou teste utilizando os subgrupos do grupo 02 - Procedimentos com finalidade diagnóstica da Tabela SUS.",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "description" : "Categoria do Exame",
        "valueSet" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRCategoriaExame-1.0"
      }
    },
    {
      "id" : "Observation.category.coding",
      "path" : "Observation.category.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Observation.category.coding.system",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.category.coding.system",
      "min" : 1
    },
    {
      "id" : "Observation.category.coding.code",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.category.coding.code",
      "min" : 1
    },
    {
      "id" : "Observation.category.coding.display",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.category.coding.display",
      "max" : "0"
    },
    {
      "id" : "Observation.category.coding.userSelected",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.category.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "Observation.category.text",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.category.text",
      "max" : "0"
    },
    {
      "id" : "Observation.code",
      "path" : "Observation.code",
      "short" : "Nome do Exame",
      "definition" : "Classifica o exame laboratorial realizado.",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "description" : "Nome do Exame",
        "valueSet" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRNomeExame-2.0"
      }
    },
    {
      "id" : "Observation.code.coding",
      "path" : "Observation.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Observation.code.coding.system",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.code.coding.system",
      "min" : 1
    },
    {
      "id" : "Observation.code.coding.code",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.code.coding.code",
      "min" : 1
    },
    {
      "id" : "Observation.code.coding.display",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.code.coding.display",
      "max" : "0"
    },
    {
      "id" : "Observation.code.coding.userSelected",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.code.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "Observation.code.text",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.code.text",
      "max" : "0"
    },
    {
      "id" : "Observation.subject",
      "path" : "Observation.subject",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.subject.reference",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.subject.reference",
      "max" : "0"
    },
    {
      "id" : "Observation.subject.type",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.subject.type",
      "max" : "0",
      "fixedUri" : "Patient"
    },
    {
      "id" : "Observation.subject.identifier",
      "path" : "Observation.subject.identifier",
      "min" : 1
    },
    {
      "id" : "Observation.subject.identifier.use",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.subject.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Observation.subject.identifier.type",
      "path" : "Observation.subject.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Observation.subject.identifier.system",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.subject.identifier.system",
      "min" : 1,
      "fixedUri" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRIndividuo-1.0"
    },
    {
      "id" : "Observation.subject.identifier.value",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.subject.identifier.value",
      "min" : 1
    },
    {
      "id" : "Observation.subject.identifier.period",
      "path" : "Observation.subject.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Observation.subject.identifier.assigner",
      "path" : "Observation.subject.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "Observation.subject.display",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.subject.display",
      "max" : "0"
    },
    {
      "id" : "Observation.focus",
      "path" : "Observation.focus",
      "max" : "0"
    },
    {
      "id" : "Observation.encounter",
      "path" : "Observation.encounter",
      "max" : "0"
    },
    {
      "id" : "Observation.effective[x]",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.effective[x]",
      "short" : "Data/hora da coleta da amostra",
      "definition" : "A data / hora da coleta da amostra para a realização do exame.",
      "min" : 1,
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "Observation.issued",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.issued",
      "short" : "Data/Hora do Resultado",
      "definition" : "Data ou data e hora que o resultado foi liberado.",
      "min" : 1
    },
    {
      "id" : "Observation.performer",
      "path" : "Observation.performer",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "identifier.system"
        }],
        "rules" : "open"
      },
      "short" : "Responsável pelo Resultado do Exame",
      "definition" : "Profissional e/ou Estabelecimento de Saúde responsável pelo resultado do exame.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.performer:estabelecimentoSaude",
      "path" : "Observation.performer",
      "sliceName" : "estabelecimentoSaude",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.performer:estabelecimentoSaude.reference",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.reference",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:estabelecimentoSaude.type",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.type",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:estabelecimentoSaude.identifier",
      "path" : "Observation.performer.identifier",
      "min" : 1
    },
    {
      "id" : "Observation.performer:estabelecimentoSaude.identifier.use",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:estabelecimentoSaude.identifier.type",
      "path" : "Observation.performer.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:estabelecimentoSaude.identifier.system",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.identifier.system",
      "min" : 1,
      "fixedUri" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BREstabelecimentoSaude-1.0"
    },
    {
      "id" : "Observation.performer:estabelecimentoSaude.identifier.value",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.identifier.value",
      "min" : 1
    },
    {
      "id" : "Observation.performer:estabelecimentoSaude.identifier.period",
      "path" : "Observation.performer.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:estabelecimentoSaude.identifier.assigner",
      "path" : "Observation.performer.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:estabelecimentoSaude.display",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.display",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:pessoaJuridicaProfissionalLiberal",
      "path" : "Observation.performer",
      "sliceName" : "pessoaJuridicaProfissionalLiberal",
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRPessoaJuridicaProfissionalLiberal-1.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.performer:pessoaJuridicaProfissionalLiberal.reference",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.reference",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:pessoaJuridicaProfissionalLiberal.type",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.type",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:pessoaJuridicaProfissionalLiberal.identifier",
      "path" : "Observation.performer.identifier",
      "min" : 1
    },
    {
      "id" : "Observation.performer:pessoaJuridicaProfissionalLiberal.identifier.use",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:pessoaJuridicaProfissionalLiberal.identifier.type",
      "path" : "Observation.performer.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:pessoaJuridicaProfissionalLiberal.identifier.system",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.identifier.system",
      "min" : 1,
      "fixedUri" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRPessoaJuridicaProfissionalLiberal-1.0"
    },
    {
      "id" : "Observation.performer:pessoaJuridicaProfissionalLiberal.identifier.value",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.identifier.value",
      "min" : 1
    },
    {
      "id" : "Observation.performer:pessoaJuridicaProfissionalLiberal.identifier.period",
      "path" : "Observation.performer.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:pessoaJuridicaProfissionalLiberal.identifier.assigner",
      "path" : "Observation.performer.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:pessoaJuridicaProfissionalLiberal.display",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.display",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:lotacaoProfissional",
      "path" : "Observation.performer",
      "sliceName" : "lotacaoProfissional",
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRLotacaoProfissional-1.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.performer:lotacaoProfissional.reference",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.reference",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:lotacaoProfissional.type",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.type",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:lotacaoProfissional.identifier",
      "path" : "Observation.performer.identifier",
      "min" : 1
    },
    {
      "id" : "Observation.performer:lotacaoProfissional.identifier.use",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.identifier.use",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:lotacaoProfissional.identifier.type",
      "path" : "Observation.performer.identifier.type",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:lotacaoProfissional.identifier.system",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.identifier.system",
      "min" : 1,
      "fixedUri" : "http://www.saude.gov.br/fhir/r4/StructureDefinition/BRLotacaoProfissional-1.0"
    },
    {
      "id" : "Observation.performer:lotacaoProfissional.identifier.value",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.identifier.value",
      "min" : 1
    },
    {
      "id" : "Observation.performer:lotacaoProfissional.identifier.period",
      "path" : "Observation.performer.identifier.period",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:lotacaoProfissional.identifier.assigner",
      "path" : "Observation.performer.identifier.assigner",
      "max" : "0"
    },
    {
      "id" : "Observation.performer:lotacaoProfissional.display",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.performer.display",
      "max" : "0"
    },
    {
      "id" : "Observation.value[x]",
      "path" : "Observation.value[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "closed"
      },
      "short" : "Valor do Resultado",
      "definition" : "Pode ser um valor quantitativo, utilizando Quantity, ou um valor qualitativo, utilizando CodeableConcept.",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      },
      {
        "code" : "CodeableConcept"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x]:valueQuantity",
      "path" : "Observation.value[x]",
      "sliceName" : "valueQuantity",
      "short" : "Resultado quantitativo",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Quantity"
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.value[x]:valueCodeableConcept",
      "path" : "Observation.value[x]",
      "sliceName" : "valueCodeableConcept",
      "short" : "Resultado qualitativo",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "description" : "Resultado Qualitativo do Exame",
        "valueSet" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRResultadoQualitativoExame-2.0"
      }
    },
    {
      "id" : "Observation.dataAbsentReason",
      "path" : "Observation.dataAbsentReason",
      "max" : "0"
    },
    {
      "id" : "Observation.interpretation",
      "path" : "Observation.interpretation",
      "short" : "Interpretação Qualitativa",
      "definition" : "Interpretação qualitativa de um resultado quantitativo.",
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "description" : "Interperetação Qualitativa do Exame",
        "valueSet" : "http://www.saude.gov.br/fhir/r4/ValueSet/BRResultadoQualitativoExame-1.0"
      }
    },
    {
      "id" : "Observation.interpretation.coding",
      "path" : "Observation.interpretation.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Observation.interpretation.coding.system",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.interpretation.coding.system",
      "min" : 1
    },
    {
      "id" : "Observation.interpretation.coding.code",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.interpretation.coding.code",
      "min" : 1
    },
    {
      "id" : "Observation.interpretation.coding.display",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.interpretation.coding.display",
      "max" : "0"
    },
    {
      "id" : "Observation.interpretation.coding.userSelected",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.interpretation.coding.userSelected",
      "max" : "0"
    },
    {
      "id" : "Observation.interpretation.text",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.interpretation.text",
      "max" : "0"
    },
    {
      "id" : "Observation.note",
      "path" : "Observation.note",
      "short" : "Notas",
      "definition" : "Comentários sobre os resultados dos exames.",
      "mustSupport" : true
    },
    {
      "id" : "Observation.note.author[x]",
      "path" : "Observation.note.author[x]",
      "max" : "0"
    },
    {
      "id" : "Observation.note.time",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.note.time",
      "max" : "0"
    },
    {
      "id" : "Observation.bodySite",
      "path" : "Observation.bodySite",
      "max" : "0"
    },
    {
      "id" : "Observation.method",
      "path" : "Observation.method",
      "short" : "Método",
      "definition" : "Método analítico utilizado para determinação do resultado do analito.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Observation.method.coding",
      "path" : "Observation.method.coding",
      "max" : "0"
    },
    {
      "id" : "Observation.method.text",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.method.text",
      "mustSupport" : true
    },
    {
      "id" : "Observation.specimen",
      "path" : "Observation.specimen",
      "short" : "Amostra",
      "definition" : "A amostra que foi usada quando esta observação foi realizada.",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://www.saude.gov.br/fhir/r4/StructureDefinition/BRAmostraBiologica-1.0"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Observation.specimen.reference",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.specimen.reference",
      "min" : 1
    },
    {
      "id" : "Observation.specimen.type",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.specimen.type",
      "max" : "0"
    },
    {
      "id" : "Observation.specimen.identifier",
      "path" : "Observation.specimen.identifier",
      "max" : "0"
    },
    {
      "id" : "Observation.specimen.display",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.specimen.display",
      "max" : "0"
    },
    {
      "id" : "Observation.device",
      "path" : "Observation.device",
      "max" : "0"
    },
    {
      "id" : "Observation.referenceRange",
      "path" : "Observation.referenceRange",
      "short" : "Valor de Referência",
      "definition" : "Faixa de valores de resultado esperada para determinada população de indivíduos.",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Observation.referenceRange.low",
      "path" : "Observation.referenceRange.low",
      "max" : "0"
    },
    {
      "id" : "Observation.referenceRange.high",
      "path" : "Observation.referenceRange.high",
      "max" : "0"
    },
    {
      "id" : "Observation.referenceRange.type",
      "path" : "Observation.referenceRange.type",
      "max" : "0"
    },
    {
      "id" : "Observation.referenceRange.appliesTo",
      "path" : "Observation.referenceRange.appliesTo",
      "max" : "0"
    },
    {
      "id" : "Observation.referenceRange.age",
      "path" : "Observation.referenceRange.age",
      "max" : "0"
    },
    {
      "id" : "Observation.referenceRange.text",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
        "valueCode" : "4.0.0"
      }],
      "path" : "Observation.referenceRange.text",
      "min" : 1
    },
    {
      "id" : "Observation.hasMember",
      "path" : "Observation.hasMember",
      "max" : "0"
    },
    {
      "id" : "Observation.derivedFrom",
      "path" : "Observation.derivedFrom",
      "max" : "0"
    },
    {
      "id" : "Observation.component",
      "path" : "Observation.component",
      "max" : "0"
    }]
  }
}

```
