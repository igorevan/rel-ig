# Exames LOINC - Guia de Implementação do Resultado de Exame Laboratorial (REL) da RNDS v1.0.0-release

## CodeSystem: Exames LOINC 

 
Classifica o exame laboratorial realizado em amostra biológica para diagnóstico laboratorial, de acordo com a terminologia LOINC. 

This Code system is referenced in the definition of the following value sets:

* [Nome do Exame](ValueSet-BRNomeExame-2.0.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRNomeExameLOINC",
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/rel/ImplementationGuide/br.gov.saude.rel.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/rel/ImplementationGuide/br.gov.saude.rel.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRNomeExameLOINC",
  "version" : "1.0.0-release",
  "name" : "BRNomeExameLOINC",
  "title" : "Exames LOINC",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-04-29T20:29:49.3397125+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Classifica o exame laboratorial realizado em amostra biológica para diagnóstico laboratorial, de acordo com a terminologia LOINC.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "94306-8",
    "display" : "SARS Coronavírus 2 Painel de RNA - Amostra Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94307-6",
    "display" : "SARS Coronavírus, [presença de] gene 2 N em amostra não especificada por amplificação de ácido nucleico usando conjunto de sonda / primer N1"
  },
  {
    "code" : "94308-4",
    "display" : "SARS Coronavírus 2, [presença de] gene N em amostra não especificada, por amplificação de ácido nucleico usando conjunto de sonda / primer N2"
  },
  {
    "code" : "94309-2",
    "display" : "SARS Coronavírus 2, [presença de] RNA em amostra não especificada, por amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94310-0",
    "display" : "SARS (como) Coronavírus  [Presença de] gene N em Amostra Inespecífica por Amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94311-8",
    "display" : "SARS Coronavírus 2, [limiar de ciclo] de gene N em amostra não especificada por amplificação de ácido nucleico usando conjunto de sonda / primer N1"
  },
  {
    "code" : "94312-6",
    "display" : "SARS Coronavírus 2, [limiar de ciclo] de gene N em amostra não especificada por amplificação de ácido nucleico usando conjunto de sonda / primer N2"
  },
  {
    "code" : "94313-4",
    "display" : "SARS (como) Coronavírus [Limiar de ciclo de] gene N em Amostra Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94314-2",
    "display" : "SARS Coronavírus 2, [presença de] gene RdRp em amostra não especificada por amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94315-9",
    "display" : "SARS Coronavírus 2, [presença de] gene E em amostra não especificada por amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94316-7",
    "display" : "SARS Coronavírus 2, [presença de] gene N em amostra não especificada por amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94500-6",
    "display" : "SARS Coronavírus 2, [presença de] RNA em amostra respiratória por amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94502-2",
    "display" : "SARS Coronavírus relacionado, [presença de] RNA em amostra respiratória por amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94503-0",
    "display" : "SARS Coronavírus 2 painel -  anticorpos em Soro, Plasma ou Sangue por Imunoensaio rápido"
  },
  {
    "code" : "94504-8",
    "display" : "SARS Coronavírus 2 painel - anticorpos, Soro ou Plasma por Imunoensaio rápido"
  },
  {
    "code" : "94505-5",
    "display" : "SARS Coronavírus 2, [dosagem de] anticorpos IgG [Unidades/Volume] em soro ou plasma por imunoensaio"
  },
  {
    "code" : "94506-3",
    "display" : "SARS Coronavírus 2, [dosagem de] anticorpos IgM [Unidades/Volume] em soro ou plasma por imunoensaio"
  },
  {
    "code" : "94507-1",
    "display" : "SARS Coronavírus 2, [presença de] anticorpos IgG em soro ou plasma por imunoensaio"
  },
  {
    "code" : "94508-9",
    "display" : "SARS Coronavírus 2, [presença de] anticorpos IgM em soro ou plasma por imunoensaio"
  },
  {
    "code" : "94509-7",
    "display" : "SARS Coronavírus 2, [limiar de ciclo de] gene E em amostra não especificada por amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94510-5",
    "display" : "SARS Coronavírus 2, [limiar de ciclo de] gene 2 N em amostra não especificada por amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94511-3",
    "display" : "SARS Coronavírus 2, [limiar de ciclo da] região ORF1ab em amostra não especificada por amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94531-1",
    "display" : "SARS Coronavírus 2 painel RNA - em Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94532-9",
    "display" : "SARS Coronavírus relacionado + MERS Coronavírus, [presença de] RNA em amostra respiratória por amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94533-7",
    "display" : "SARS Coronavírus 2, [presença de] gene N em amostra respiratória por amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94534-5",
    "display" : "SARS Coronavírus 2, [presença de] gene RdRp em amostra respiratória por amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94547-7",
    "display" : "SARS Coronavírus 2, [presença de] anticorpos IgG e IgM em soro ou plasma por imunoensaio"
  },
  {
    "code" : "94558-4",
    "display" : "SARS Coronavírus 2, [presença de] antígenos Ag em amostra respiratória por imunoensaio rápido"
  },
  {
    "code" : "94559-2",
    "display" : "SARS Coronavírus 2, [presença de] gene da regição ORF1ab em amostra respiratória por amplificação do ácido nucléico com detecção por sonda"
  },
  {
    "code" : "94562-6",
    "display" : "SARS Coronavírus 2, [presença de] anticorpos IgA Ab em soro ou plasma por imunoensaio"
  },
  {
    "code" : "94563-4",
    "display" : "SARS Coronavírus 2, [presença de] anticorpos IgG Ab em soro ou plasma por imunoensaio"
  },
  {
    "code" : "94564-2",
    "display" : "SARS Coronavírus 2, [presença de] anticorpos IgM Ab em soro ou plasma por imunoensaio"
  },
  {
    "code" : "94565-9",
    "display" : "SARS Coronavírus 2, [presença de] DNA em rinofaringe por NAA por detecção sem sonda"
  },
  {
    "code" : "94639-2",
    "display" : "SARS Coronavírus 2 [Presença de] região anticorpos ORF1 em Amostra Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94640-0",
    "display" : "SARS Coronavírus 2 [Presença de] gene S em Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94641-8",
    "display" : "SARS Coronavírus 2 [Presença de] gene S em Amostra Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94642-6",
    "display" : "SARS Coronavírus 2 [Limiar de ciclo de] gene S em Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94643-4",
    "display" : "SARS Coronavírus 2 [Limiar de ciclo de] gene S em Amostra Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94644-2",
    "display" : "SARS Coronavírus 2 [Limiar de ciclo de] região anticorpos ORF1 em Amostra respiratória por Amplificação do ácido nucleico"
  },
  {
    "code" : "94645-9",
    "display" : "SARS Coronavírus 2 [Limiar de ciclo de] gene RdRp em Amostra Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94646-7",
    "display" : "SARS Coronavírus 2 [Limiar de ciclo de] gene RdRp em Amostra respiratória por Amplificação do ácido nucleico"
  },
  {
    "code" : "94647-5",
    "display" : "SARS Coronavírus relacionado [Presença de] RNA em Amosta Inespecífica por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94660-8",
    "display" : "SARS Coronavírus 2 [Presença de] em Soro ou Plasma por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94661-6",
    "display" : "SARS Coronavírus 2 [Interpretação de] anticorpos em Soro ou Plasma"
  },
  {
    "code" : "94720-0",
    "display" : "SARS Coronavírus 2 [dosagem de] anticorpos IgA em Soro ou Plasma por Imunoensaio"
  },
  {
    "code" : "94745-7",
    "display" : "SARS Coronavírus 2 [Limiar de ciclo de] RNA em Amostra respiratória por Amplificação do ácido nucleico"
  },
  {
    "code" : "94746-5",
    "display" : "SARS Coronavírus 2 [Limiar de ciclo de] RNA em Amostra Inespecífica por Amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94756-4",
    "display" : "SARS Coronavírus 2 [Presença de] gene N em Amostra respiratória por Amplificação do ácido nucleido usando sonda primer set N1"
  },
  {
    "code" : "94757-2",
    "display" : "SARS Coronavírus 2 [Presença de] gene N em Amostra respiratória por Amplificação do ácido nucleico usando sonda primer set N2"
  },
  {
    "code" : "94758-0",
    "display" : "SARS Coronavírus relacionado [Presença de] gene E em Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94759-8",
    "display" : "SARS Coronavírus 2 [Presença de] RNA em Nasofaringe por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94760-6",
    "display" : "SARS Coronavírus 2 [Presença de] gene N em Nasofaringe por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94761-4",
    "display" : "SARS Coronavírus 2 [Presença de] anticorpos IgG em teste em Amostra de sangue seco por Imunoensaio"
  },
  {
    "code" : "94762-2",
    "display" : "SARS Coronavírus 2 [Presença de] anticorpos em Soro ou Plasma por Imunoensaio"
  },
  {
    "code" : "94763-0",
    "display" : "SARS Coronavírus 2 [Presença de] em Amostra não específica por cultura em organismo específico"
  },
  {
    "code" : "94765-5",
    "display" : "SARS Coronavírus relacionado [Presença de] gene E em Soro ou Plasma por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94766-3",
    "display" : "SARS Coronavírus 2 [Presença de] gene N em Soro ou Plasma por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94767-1",
    "display" : "SARS Coronavírus 2 [Presença de] gene S em Soro ou Plasma por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94768-9",
    "display" : "SARS Coronavírus 2 [Presença de] anticorpos IgA em Soro Plasma ou Sangue por Imunoensaio rápido"
  },
  {
    "code" : "94769-7",
    "display" : "SARS Coronavírus 2 [dosagem de] anticorpos em Soro ou Plasma por Imunoensaio"
  },
  {
    "code" : "94819-0",
    "display" : "SARS Coronavírus 2 [dosagem de] (carga viral) RNA em Amostra Inespecífica por Amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "94845-5",
    "display" : "SARS Coronavírus 2 [Presença de] RNA em Saliva (fluido oral) por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "95125-1",
    "display" : "SARS Coronavírus 2  [Presença de] IgA+IgM em Soro ou Plasma por Imunoensaio"
  },
  {
    "code" : "95209-3",
    "display" : "SARS Coronavírus + SARS Coronavírus 2 [Presença de] antígeno em Amostra respiratória por Imunoensaio rápido"
  },
  {
    "code" : "95380-2",
    "display" : "Vírus da Influenza A e B e SARS Coronavírus 2 e SARS Coronavírus relacionado painel de RNA por Amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "95406-5",
    "display" : "SARS Coronavírus 2, [Presença de] RNA no Nariz por Amplificação de ácido nucléico com detecção por sonda"
  },
  {
    "code" : "95409-9",
    "display" : "SARS Coronavírus 2, [Presença de] gene N em Nariz por  Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "95410-7",
    "display" : "SARS Coronavírus 2, [Concentração de] neutralização de anticorpos em Soro por teste de neutralização de pseudovírus"
  },
  {
    "code" : "95411-5",
    "display" : "SARS Coronavírus 2, [Presença de] neutralização de anticorpos em Soro por teste de neutralização de pseudovírus"
  },
  {
    "code" : "95416-4",
    "display" : "SARS Coronavírus 2, [Presença de] anticorpos IgM teste em Amostra de Sangue seco por Imunoensaio"
  },
  {
    "code" : "95422-2",
    "display" : "Vírus da Influenza A e B RNA e SARS Coronavírus 2 painel de gene N - Amostra respiratória por Amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "95423-0",
    "display" : "Vírus da Influenza A e B e SARS Coronavírus 2 identificado em  Amostra respiratória por Amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "95425-5",
    "display" : "SARS Coronavírus 2 [Presença de] gene N em Saliva (fluido oral) por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "95427-1",
    "display" : "SARS Coronavírus 2 [Concentração de] anticorpos IgA em Soro ou Plasma por imunofluorescência"
  },
  {
    "code" : "95428-9",
    "display" : "SARS Coronavírus 2 [Concentração de] anticorpos IgM em Soro ou Plasma por imunofluorescência"
  },
  {
    "code" : "95429-7",
    "display" : "SARS Coronavírus 2 [Concentração de] anticorpos IgG em Soro ou Plasma por imunofluorescência"
  },
  {
    "code" : "95521-1",
    "display" : "SARS Coronavírus 2 [#/volume] (carga viral) gene N em Amostra respiratória por Amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "95522-9",
    "display" : "SARS Coronavírus 2 [dosagem de] (carga viral ) gene N em Amostra respiratória por Amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "95542-7",
    "display" : "SARS Coronavírus 2 anticorposs IgG+IgM [Presença de] em Soro Plasma ou Sangue por Imunoensaio rápido"
  },
  {
    "code" : "95608-6",
    "display" : "SARS Coronavírus 2  [Presença de] RNA em amostra respiraória por Amplificação de ácido nucleico com detecção sem sonda"
  },
  {
    "code" : "95823-1",
    "display" : "SARS Coronavírus relacionado [Presença de] gene E em Saliva (fluido oral) por Amplificação de àcido nucleico com detecção por sonda"
  },
  {
    "code" : "95824-9",
    "display" : "SARS Coronavírus 2 [Presença de] região anticorpos ORF1 em Saliva (fluido oral) por Amplificação de ácido nucléico com detecção por sonda"
  },
  {
    "code" : "95825-6",
    "display" : "SARS Coronavírus 2 [Presença de] anticorpos em Amostra de Sangue seco por Imunoensaio"
  },
  {
    "code" : "95826-4",
    "display" : "SARS Coronavírus 2 painel de RNA - Saliva (fluido oral) por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "95941-1",
    "display" : "Vírus da Influenza A e B e SARS Coronavírus 2 e Vírus sinciciais respiratórios painel de RNA - Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "95942-9",
    "display" : "Vírus da Influenza A e B e SARS Coronavírus + SARS Coronavírus 2 painel de antígeno - Amostra de trato respiratório superior por Imunoensaio rápido"
  },
  {
    "code" : "95971-8",
    "display" : "SARS Coronavírus 2 estimulado por interferon gama [Presença de] em sangue"
  },
  {
    "code" : "95972-6",
    "display" : "SARS Coronavírus 2 estimulado por  interferon gama liberação por células T [Unidades/Volumes] corrigido para fundo em sangue"
  },
  {
    "code" : "95973-4",
    "display" : "SARS Coronavírus 2 estimulado por interferon gama liberação por células T (Unidades/Volume] em sangue"
  },
  {
    "code" : "95974-2",
    "display" : "SARS Coronavírus 2 estimulado por interferon gama painel - Sangue"
  },
  {
    "code" : "96091-4",
    "display" : "SARS Coronavírus 2 gene RdRp [Presença de] em saliva (fluído oral) por Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96094-8",
    "display" : "SARS Coronavírus 2 e SARS Coronavírus relacionado painel de RNA - Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96118-5",
    "display" : "SARS Coronavírus 2 painel de anticorpos -  Amostra de sangue seco por Imunoensaio"
  },
  {
    "code" : "96119-3",
    "display" : "SARS Coronavírus 2 antígenos [Presença de] Amostra de trato respiratório superior por Imunoensaio"
  },
  {
    "code" : "96120-1",
    "display" : "SARS Coronavírus 2 gene RdRp [Presença de] em Amostra de trato respiratório inferior por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96121-9",
    "display" : "SARS Coronavírus relacionado gene E [Presença de] em Amostra de trato respiratório inferior por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96122-7",
    "display" : "SARS Coronavírus relacionado gene E [Presença de] em Amostra de trato respiratório superior por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96123-5",
    "display" : "SARS Coronavírus 2 gene RdRp [Presença de] em Amostra de trato respiratório superior por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96448-6",
    "display" : "SARS Coronavírus 2 gene N [Presença de] em saliva (fluído oral) por amplicação de ácido nucleico usando sonda primer set N1"
  },
  {
    "code" : "96603-6",
    "display" : "SARS Coronavírus 2 proteína S domínio de ligação ao RNA anticorpo neutralizante [Presença] em soro ou plasma por imunonensaio"
  },
  {
    "code" : "96742-2",
    "display" : "SARS Coronavírus 2 anticorpos IgG [Massa/Volume] em soro ou plasma por imunoensaio"
  },
  {
    "code" : "96751-3",
    "display" : "SARS Coronavírus 2 gene S mutação detectada [Identificador] em specime por método genética molecular"
  },
  {
    "code" : "96752-1",
    "display" : "SARS Coronavírus 2 gene S mutação detectada [Presença de] em amostra por método genética molecular"
  },
  {
    "code" : "96755-4",
    "display" : "SARS Coronavirus 2 interpetação de variante em Amostra narrativa"
  },
  {
    "code" : "96763-8",
    "display" : "SARS Coronavírus 2 gene E [Presença] em amostra respiratória por Amplificação de ácido nucléico com detecção por sonda"
  },
  {
    "code" : "96764-6",
    "display" : "SARS Coronavírus 2 gene E [Limiar de ciclo #] em Amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96765-3",
    "display" : "SARS Coronavírus 2 gene S [Presença] em saliva (fluído oral) por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96766-1",
    "display" : "Sequencia GISAID número de registro"
  },
  {
    "code" : "96797-6",
    "display" : "SARS coronavirus 2 RNA [Presença] em lavagem orofaríngea (gargarejo) por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96829-7",
    "display" : "SARS coronavirus 2 RNA [Presença de] em Amostra de doador por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96894-1",
    "display" : "SARS coronavirus 2 painel de sequenciamento e identificação - Amostra pelo método de genética molecular"
  },
  {
    "code" : "96895-8",
    "display" : "SARS coronavirus 2 linhagem [tipo] em amostra pelo método de genética molecular"
  },
  {
    "code" : "96896-6",
    "display" : "SARS coronavirus 2 clade [tipo] em amostra pelo método de genética molecular"
  },
  {
    "code" : "96897-4",
    "display" : "SARS coronavirus 2 painel de RNA - lavagem orofaríngea (gargarejo) por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96898-2",
    "display" : "SARS coronavirus 2 gene N [Limiar de ciclo#] em lavagem orofaríngea (gargarejo) por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96899-0",
    "display" : "SARS coronavirus 2 [Limiar de ciclo#] região anticorpos ORF1 (Fases de leitura aberta-1) em lavagem orofaríngea (gargarejo) por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96900-6",
    "display" : "SARS coronavirus 2 gene S [Limiar de ciclo#] em lavagem orofaríngea (gargarejo) por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96957-6",
    "display" : "SARS Coronavirus 2 gene M [Presença de] em amostra de trato respiratório superior por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "96958-4",
    "display" : "SARS Coronavirus 2 gene N [Presença] em saliva (fluído oral) por Amplicação de ácido nucleico usando sonda primer CDC set N2"
  },
  {
    "code" : "96986-5",
    "display" : "SARS coronavirus 2 gene N [Presença de] no nariz por Amplificação do ácido nucleico com detecção sem sonda"
  },
  {
    "code" : "97097-0",
    "display" : "SARS coronavirus 2 [Presença] antígenos em amostra de Trato respiratório superior por imunoensaio rápido"
  },
  {
    "code" : "97098-8",
    "display" : "SARS coronavirus 2 gene de proteína não estruturada-2 [Presença] em amostra de Trato respiratório superior por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "97099-6",
    "display" : "Vírus da Influenza A e B e SARS Coronavírus 2 painel de antígenos - Amostra de trato respiratório superior por imunoensaio rápido"
  },
  {
    "code" : "97104-4",
    "display" : "SARS coronavirus 2 região anticorpos ORF1 (Fases de leitura aberta-1) [Unidades/Volumes] (carga viral) em amostra de trato respiratório superior por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "98069-8",
    "display" : "SARS coronavirus 2 anticorpos [Presença] em Saliva (fluído oral) por imoensaio rápido"
  },
  {
    "code" : "98080-5",
    "display" : "SARS coronavírus 2 e SARS-relacionado coronavírus painel de RNA - Saliva (fluído oral) por Amplificação do ácido nucleico com detecção por sonda"
  },
  {
    "code" : "98131-6",
    "display" : "SARS coronavirus 2 região anticorpos ORF1b (Fases de leitura aberta-1b) [Presença] em amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "98132-4",
    "display" : "SARS coronavirus 2 região anticorpos ORF1a (Fases de leitura aberta-1b) [Presença] em amostra respiratória por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "98493-0",
    "display" : "SARS coronavirus 2 região anticorpos ORF1b (Fases de leitura aberta-1b) [Presença] em saliva (fluído oral)  por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "98494-8",
    "display" : "SARS coronavirus 2 região anticorpos ORF1a (Fases de leitura aberta-1a) [Presença] em saliva (fluído oral) por Amplificação de ácido nucleico com detecção por sonda"
  },
  {
    "code" : "98732-1",
    "display" : "SARS Coronavirus 2 proteína S Domínio de Ligação ao RNA anticorpo neutralizante [Fator de diluição] em soro ou plasma por imunonensaio"
  },
  {
    "code" : "98733-9",
    "display" : "Percentual de neutralização por SARS coronavirus 2 proteína spike Domínio de Ligação ao RNA anticorpo neutralizante em soro ou plasma por imunonensaio"
  },
  {
    "code" : "98734-7",
    "display" : "SARS Coronavirus 2 proteína S Domínio de Ligação ao RNA anticorpo neutralizante [Unidades/Volume] em soro ou plasma por imunonensaio"
  },
  {
    "code" : "98846-9",
    "display" : "SARS Coronavirus 2 interferon gama estimulado liberação por células T auxiliares (CD4+) [Unidades/volume] corrigido para sangue de fundo por imunoensaio"
  },
  {
    "code" : "98847-7",
    "display" : "SARS Coronavirus 2 interferon gama estimulado liberação por linfócitos [Unidades/volume] corrigido para sangue de fundo por imunoensaio"
  },
  {
    "code" : "99314-7",
    "display" : "SARS Coronavirus 2 gene RdRp mutação detectada [Identificador] em amostra pelo método de genética molecular"
  },
  {
    "code" : "99596-9",
    "display" : "SARS Coronavirus 2 proteína N [Presença] anticorpos IgG em soro ou plasma por Imunoensaio"
  },
  {
    "code" : "99597-7",
    "display" : "SARS Coronavirus 2  proteína S [Presença] anticorpos IgG em soro ou plasma por Imunoensaio"
  },
  {
    "code" : "99771-8",
    "display" : "SARS Coronavirus 2 proteína spike e proteína de nucleocapsídeo painel de interferon gama estimulado - Sangue"
  },
  {
    "code" : "99772-6",
    "display" : "SARS Coronavirus 2 interferon gama estimulado [Interpretação] em Sangue Qualitativo"
  },
  {
    "code" : "99773-4",
    "display" : "SARS Coronavirus 2 interferon gama estimulado liberado por células T. Antígeno spike área de contagem [#] corrigido para fundo em Sangue"
  },
  {
    "code" : "99774-2",
    "display" : "SARS Coronavirus 2 interferon gama estimulado liberado por células T. Antígeno nucleocapsídeo área de contagem [#] corrigido para fundo em Sangue"
  },
  {
    "code" : "41853-3",
    "display" : "Orthopoxvirus DNA [Presença de] em Amostra por Amplificação de Ácido Nucleico com detecção por sonda"
  },
  {
    "code" : "100434-0",
    "display" : "Orthopoxvirus não-varíola DNA [Presença de] em Amostra por Amplificação de Ácido Nucleico com detecção por sonda"
  },
  {
    "code" : "100383-9",
    "display" : "Vírus Monkeypox DNA [Presença de] em Amostra por Amplificação de Ácido Nucleico com detecção por sonda"
  },
  {
    "code" : "100888-7",
    "display" : "Vírus Monkeypox da Africa Ocidental DNA [Presença de] em Amostra por Amplificação de Ácido Nucleico com detecção por sonda"
  },
  {
    "code" : "100889-5",
    "display" : "Vírus Monkeypox da Bacia do Congo DNA [Presença de] em Amostra por Amplificação de Ácido Nucleico com detecção por sonda"
  },
  {
    "code" : "100885-3",
    "display" : "Parapoxvirus DNA [Presença de] em Amostra por Amplificação de Ácido Nucleico com detecção por sonda"
  },
  {
    "code" : "100886-1",
    "display" : "Vírus Orf DNA [Presença de] em Amostra por Amplificação de Ácido Nucleio com detecção por sonda"
  },
  {
    "code" : "100887-9",
    "display" : "Vírus da pseudovaríola DNA [Presença] em Amostra por Amplficação de Ácido Nucleio com detecção por sonda"
  },
  {
    "code" : "100891-1",
    "display" : "Orthopoxvirus IgG Ab [Presença] em Soro ou Plasma por Imunoensaio"
  },
  {
    "code" : "100892-9",
    "display" : "Orthopoxvirus IgM Ab [Presença] em soro ou plasma por Imunoensaio"
  },
  {
    "code" : "100893-7",
    "display" : "Orthopoxvirus IgG e IgM Ab panel - Soro ou Plasma"
  },
  {
    "code" : "40505-0",
    "display" : "Anticorpo contra o Vírus Chikungunya [Título] no soro por inibição da hemaglutinação",
    "designation" : [{
      "language" : "en",
      "value" : "Chikungunya virus Ab [Titer] in Serum by Hemagglutination inhibition"
    }]
  },
  {
    "code" : "93976-9",
    "display" : "Painel de anticorpo IgM e IgG contra o Vírus Chikungunya - Soro ou plasma",
    "designation" : [{
      "language" : "en",
      "value" : "Chikungunya virus Ab.IgM and IgG panel - Serum or Plasma"
    }]
  },
  {
    "code" : "88630-9",
    "display" : "Anticorpo IgG contra o Vírus Chikungunya [Presença] em soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Chikungunya virus IgG Ab [Presence] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "56128-2",
    "display" : "Anticorpo IgG contra o Vírus Chikungunya [Título] em soro ou plasma por imunofluorescência",
    "designation" : [{
      "language" : "en",
      "value" : "Chikungunya virus IgG Ab [Titer] in Serum or Plasma by Immunofluorescence"
    }]
  },
  {
    "code" : "97866-8",
    "display" : "Anticorpo IgG contra o Vírus Chikungunya [Unidades/volume] em soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Chikungunya virus IgG Ab [Units/volume] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "88629-1",
    "display" : "Anticorpo IgM contra o Vírus Chikungunya [Presença] em soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Chikungunya virus IgM Ab [Presence] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "56130-8",
    "display" : "Anticorpo IgM contra o Vírus Chikungunya [Título] em soro ou plasma por imunofluorescência",
    "designation" : [{
      "language" : "en",
      "value" : "Chikungunya virus IgM Ab [Titer] in Serum or Plasma by Immunofluorescence"
    }]
  },
  {
    "code" : "97867-6",
    "display" : "Anticorpo IgM contra o Vírus Chikungunya [Unidades/volume] no soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Chikungunya virus IgM Ab [Units/volume] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "86514-7",
    "display" : "RNA do Vírus Chikungunya [Presença] no líquido amniótico por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Chikungunya virus RNA [Presence] in Amniotic fluid by NAA with probe detection"
    }]
  },
  {
    "code" : "60260-7",
    "display" : "RNA do Vírus Chikungunya [Presença] no soro ou plasma por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Chikungunya virus RNA [Presence] in Serum or Plasma by NAA with probe detection"
    }]
  },
  {
    "code" : "51664-1",
    "display" : "RNA do Vírus Chikungunya [Presença] em amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Chikungunya virus RNA [Presence] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "86515-4",
    "display" : "RNA do Vírus Chikungunya [Presença] na urina por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Chikungunya virus RNA [Presence] in Urine by NAA with probe detection"
    }]
  },
  {
    "code" : "81154-7",
    "display" : "Painel de Vírus da Dengue, chikungunya e zika por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue and Chikungunya and Zika virus panel by NAA with probe detection"
    }]
  },
  {
    "code" : "55369-3",
    "display" : "Anticorpo contra o Vírus da Dengue [título] no soro por inibição da hemaglutinação",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus Ab [Titer] in Serum by Hemagglutination inhibition"
    }]
  },
  {
    "code" : "29661-6",
    "display" : "Anticorpo IgG contra o Vírus da Dengue [Presença] no soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus IgG Ab [Presence] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "100964-6",
    "display" : "Anticorpo IgG contra o Vírus da Dengue [Presença] no soro, plasma ou sangue por imunoensaio rápido",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus IgG Ab [Presence] in Serum, Plasma or Blood by Rapid immunoassay"
    }]
  },
  {
    "code" : "23991-3",
    "display" : "Anticorpo IgG contra o Vírus da Dengue [unidades/volume] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus IgG Ab [Units/volume] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "75223-8",
    "display" : "Anticorpo IgG e IgM contra o Vírus da Dengue [identificador] no soro, plasma ou sangue por imunoensaio rápido",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus IgG and IgM [Identifier] in Serum, Plasma or Blood by Rapid immunoassay"
    }]
  },
  {
    "code" : "29663-2",
    "display" : "Anticorpo IgM contra o Vírus da Dengue [Presença] no soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus IgM Ab [Presence] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "34721-1",
    "display" : "Anticorpo IgM contra o Vírus da Dengue [Presença] no líquido cefalorraquidiano",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus IgM Ab [Presence] in Cerebral spinal fluid"
    }]
  },
  {
    "code" : "23992-1",
    "display" : "Anticorpo IgM contra o Vírus da Dengue [Unidades/volume] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus IgM Ab [Units/volume] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "91064-6",
    "display" : "Antígeno NS1 do Vírus da Dengue [Presença] no soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus NS1 Ag [Presence] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "75377-2",
    "display" : "Antígeno NS1 do Vírus da Dengue [Presença] no soro, plasma ou sangue por imunoensaio rápido",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus NS1 Ag [Presence] in Serum, Plasma or Blood by Rapid immunoassay"
    }]
  },
  {
    "code" : "101206-1",
    "display" : "Antígeno NS1 do Vírus da Dengue [Unidades/volume] no soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus NS1 Ag [Units/volume] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "41878-0",
    "display" : "Painel IgG e IgM contra o Vírus da Dengue - soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus IgG and IgM panel - Serum by Immunoassay"
    }]
  },
  {
    "code" : "60262-3",
    "display" : "RNA do Vírus da Dengue 1 [Presença] no soro por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus 1 RNA [Presence] in Serum by NAA with probe detection"
    }]
  },
  {
    "code" : "33578-6",
    "display" : "Anticorpo contra o Vírus da Dengue [título] no soro por imunofluorescência",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus Ab [Titer] in Serum by Immunofluorescence"
    }]
  },
  {
    "code" : "77958-7",
    "display" : "RNA do Vírus da Dengue 1, 2, 3 e 4 [Identificador] no líquido cefalorraquidiano por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus 1 and 2 and 3 and 4 RNA [Identifier] in Cerebral spinal fluid by NAA with probe detection"
    }]
  },
  {
    "code" : "88188-8",
    "display" : "RNA do Vírus da Dengue 1+2+3+4 [Presença] na urina por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus 1+2+3+4 RNA [Presence] in Urine by NAA with probe detection"
    }]
  },
  {
    "code" : "94837-2",
    "display" : "RNA do Vírus da Dengue 1+2+3+4 [Presença] no líquido amniótico por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus 1+2+3+4 RNA [Presence] in Amniotic fluid by NAA with probe detection"
    }]
  },
  {
    "code" : "88189-6",
    "display" : "RNA do Vírus da Dengue 1+2+3+4 [Presença] no sangue por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus 1+2+3+4 RNA [Presence] in Blood by NAA with probe detection"
    }]
  },
  {
    "code" : "7855-0",
    "display" : "RNA do Vírus da Dengue 1+2+3+4 [Presença] no soro por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus 1+2+3+4 RNA [Presence] in Serum or Plasma by NAA with probe detection"
    }]
  },
  {
    "code" : "60420-7",
    "display" : "RNA do Vírus da Dengue 2 [Presença] no soro por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus 2 RNA [Presence] in Serum by NAA with probe detection"
    }]
  },
  {
    "code" : "60419-9",
    "display" : "RNA do Vírus da Dengue 3 [Presença] no soro por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus 3 RNA [Presence] in Serum by NAA with probe detection"
    }]
  },
  {
    "code" : "60418-1",
    "display" : "RNA do Vírus da Dengue 4 [Presença] no soro por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Dengue virus 4 RNA [Presence] in Serum by NAA with probe detection"
    }]
  },
  {
    "code" : "41239-5",
    "display" : "Anticorpo contra o Vírus da Febre Amarela [Presença] no líquido cefalorraquidiano",
    "designation" : [{
      "language" : "en",
      "value" : "Yellow fever virus Ab [Presence] in Cerebral spinal fluid"
    }]
  },
  {
    "code" : "97868-4",
    "display" : "Painel de anticorpo contra o Vírus da Febre Amarela - soro ou plasma",
    "designation" : [{
      "language" : "en",
      "value" : "Yellow fever virus Ab panel - Serum or Plasma"
    }]
  },
  {
    "code" : "77954-6",
    "display" : "Anticorpo IgG contra o Vírus da Febre Amarela [Presença] no soro por imunofluorescência",
    "designation" : [{
      "language" : "en",
      "value" : "Yellow fever virus IgG Ab [Presence] in Serum by Immunofluorescence"
    }]
  },
  {
    "code" : "95675-5",
    "display" : "Anticorpo IgG contra o Vírus da Febre Amarela [Presença] em amostra por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Yellow fever virus IgG Ab [Presence] in Specimen by Immunoassay"
    }]
  },
  {
    "code" : "6592-0",
    "display" : "Anticorpo IgG contra o Vírus da Febre Amarela [Unidades/volume] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Yellow fever virus IgG Ab [Units/volume] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "71782-7",
    "display" : "Anticorpo IgM contra o Vírus da Febre Amarela [Presença] no líquido cefalorraquidiano por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Yellow fever virus IgM Ab [Presence] in Cerebral spinal fluid by Immunoassay"
    }]
  },
  {
    "code" : "77955-3",
    "display" : "Anticorpo IgM contra o Vírus da Febre Amarela [Presença] no soro por imunofluorescência",
    "designation" : [{
      "language" : "en",
      "value" : "Yellow fever virus IgM Ab [Presence] in Serum by Immunofluorescence"
    }]
  },
  {
    "code" : "95690-4",
    "display" : "Anticorpo IgM contra o Vírus da Febre Amarela [Presença] na amostra por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Yellow fever virus IgM Ab [Presence] in Specimen by Immunoassay"
    }]
  },
  {
    "code" : "6593-8",
    "display" : "Anticorpo IgM contra o Vírus da Febre Amarela [Unidades/volume] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Yellow fever virus IgM Ab [Units/volume] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "90459-9",
    "display" : "RNA do Vírus da Febre Amarela [Presença] no sangue por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Yellow fever virus RNA [Presence] in Blood by NAA with probe detection"
    }]
  },
  {
    "code" : "8057-2",
    "display" : "RNA do Vírus da Febre Amarela [Presença] no soro por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Yellow fever virus RNA [Presence] in Serum by NAA with probe detection"
    }]
  },
  {
    "code" : "94184-9",
    "display" : "RNA do Vírus da Febre Amarela [Presença] na amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Yellow fever virus RNA [Presence] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "97869-2",
    "display" : "Painel de anticorpo contra o Vírus Zika - soro ou plasma",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus Ab panel - Serum or Plasma"
    }]
  },
  {
    "code" : "91080-2",
    "display" : "Anticorpo IgG contra o Vírus Zika [Presença] no soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus IgG Ab [Presence] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "95663-1",
    "display" : "Anticorpo IgG contra o Vírus Zika [Presença] em amostra por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus IgG Ab [Presence] in Specimen by Immunoassay"
    }]
  },
  {
    "code" : "89590-4",
    "display" : "Anticorpo IgG contra o Vírus Zika [título] no soro por imunofluorescência",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus IgG Ab [Titer] in Serum by Immunofluorescence"
    }]
  },
  {
    "code" : "97870-0",
    "display" : "Anticorpo IgG contra o Vírus Zika [unidades/volume] no soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus IgG Ab [Units/volume] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "80823-8",
    "display" : "Anticorpo IgM contra o Vírus Zika [Presença] no líquido cefalorraquidiano por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus IgM Ab [Presence] in Cerebral spinal fluid by Immunoassay"
    }]
  },
  {
    "code" : "80824-6",
    "display" : "Anticorpo IgM contra o Vírus Zika [Presença] no soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus IgM Ab [Presence] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "91678-3",
    "display" : "Anticorpo IgM contra o Vírus Zika [Presença] no soro, plasma ou sangue por imunoensaio rápido",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus IgM Ab [Presence] in Serum, Plasma or Blood by Rapid immunoassay"
    }]
  },
  {
    "code" : "89591-2",
    "display" : "Anticorpo IgM contra o Vírus Zika [Título] no soro por imunofluorescência",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus IgM Ab [Titer] in Serum by Immunofluorescence"
    }]
  },
  {
    "code" : "80618-2",
    "display" : "Anticorpo IgM contra o Vírus Zika [Unidades/volume] no líquido cefalorraquidiano por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus IgM Ab [Units/volume] in Cerebral spinal fluid by Immunoassay"
    }]
  },
  {
    "code" : "80619-0",
    "display" : "Anticorpo IgM contra o Vírus Zika [Unidades/volume] no soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus IgM Ab [Units/volume] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "85621-1",
    "display" : "RNA do Vírus Zika [Presença] no líquido amniótico por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus RNA [Presence] in Amniotic fluid by NAA with probe detection"
    }]
  },
  {
    "code" : "91078-6",
    "display" : "RNA do Vírus Zika [Presença] no sangue por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus RNA [Presence] in Blood by NAA with probe detection"
    }]
  },
  {
    "code" : "86594-9",
    "display" : "RNA do Vírus Zika [Presença] no líquido cefalorraquidiano por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus RNA [Presence] in Cerebral spinal fluid by NAA with probe detection"
    }]
  },
  {
    "code" : "90462-3",
    "display" : "RNA do Vírus Zika [Presença] no sangue do cordão umbilical por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus RNA [Presence] in Cord blood by NAA with probe detection"
    }]
  },
  {
    "code" : "91079-4",
    "display" : "RNA do Vírus Zika [Presença] na placenta por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus RNA [Presence] in Placenta by NAA with probe detection"
    }]
  },
  {
    "code" : "85622-9",
    "display" : "RNA do Vírus Zika [Presença] no soro ou plasma por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus RNA [Presence] in Serum or Plasma by NAA with probe detection"
    }]
  },
  {
    "code" : "79190-5",
    "display" : "RNA do Vírus Zika [Presença] em amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus RNA [Presence] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "85623-7",
    "display" : "RNA do Vírus Zika [Presença] na urina por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Zika virus RNA [Presence] in Urine by NAA with probe detection"
    }]
  },
  {
    "code" : "29568-3",
    "display" : "Anticorpo neutralizante contra o Vírus do Nilo Ocidental [Título] no soro por teste de neutralização",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus neutralizing antibody [Titer] in Serum by Neutralization test"
    }]
  },
  {
    "code" : "34892-0",
    "display" : "RNA do Vírus do Nilo Ocidental [Presença] na amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus RNA [Presence] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "95650-8",
    "display" : "Anticorpo neutralizante contra o Vírus Mayaro [Título] na amostra por teste de neutralização",
    "designation" : [{
      "language" : "en",
      "value" : "Mayaro virus neutralizing antibody [Titer] in Specimen by Neutralization test"
    }]
  },
  {
    "code" : "99120-8",
    "display" : "Anticorpo neutralizante contra o Vírus Oropouche [Título] na amostra por teste de neutralização",
    "designation" : [{
      "language" : "en",
      "value" : "Oropouche virus neutralizing antibody [Titer] in Specimen by Neutralization test"
    }]
  },
  {
    "code" : "96506-1",
    "display" : "Anticorpo IgG contra o Vírus Oropouche [Presença] na amostra por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Oropouche virus IgG Ab [Presence] in Specimen by Immunoassay"
    }]
  },
  {
    "code" : "96531-9",
    "display" : "Anticorpo IgM contra o Vírus Oropouche [Presença] na amostra por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Oropouche virus IgM Ab [Presence] in Specimen by Immunoassay"
    }]
  },
  {
    "code" : "77953-8",
    "display" : "Anticorpo IgG contra o Vírus do Nilo Ocidental [Presença] no líquido cefalorraquidiano por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgG Ab [Presence] in Cerebral spinal fluid by Immunoassay"
    }]
  },
  {
    "code" : "29538-6",
    "display" : "Vírus do Nilo Ocidental Igm Ac [unidades/volume] em líquido espinhal cerebral",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgM Ab [Units/volume] in Cerebral spinal fluid"
    }]
  },
  {
    "code" : "97931-0",
    "display" : "RNA do Vírus Mayaro [Presença] na amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Mayaro virus RNA [Presence] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "97917-9",
    "display" : "RNA do Vírus Oropouche [Presença] na amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Oropouche virus RNA [Presence] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "33330-2",
    "display" : "Anticorpo IgM contra o Vírus do Nilo Ocidental [Título] no líquido cefalorraquidiano",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgM Ab [Titer] in Cerebral spinal fluid"
    }]
  },
  {
    "code" : "29566-7",
    "display" : "Anticorpo IgG contra o Vírus do Nilo Ocidental [Presença] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgG Ab [Presence] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "33328-6",
    "display" : "Anticorpo IgG contra o Vírus do Nilo Ocidental [título] no líquido cefalorraquidiano",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgG Ab [Titer] in Cerebral spinal fluid"
    }]
  },
  {
    "code" : "33329-4",
    "display" : "Anticorpo IgG contra o Vírus do Nilo Ocidental [Título] no soro",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgG Ab [Titer] in Serum"
    }]
  },
  {
    "code" : "39572-3",
    "display" : "Anticorpo IgG contra o Vírus do Nilo Ocidental [Unidades/volume] no líquido cefalorraquidiano por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgG Ab [Units/volume] in Cerebral spinal fluid by Immunoassay"
    }]
  },
  {
    "code" : "38997-3",
    "display" : "Anticorpo IgG contra o Vírus do Nilo Ocidental [unidades/volume] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgG Ab [Units/volume] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "29570-9",
    "display" : "Anticorpo neutralizante do vírus do Nilo Ocidental [Título] no líquido espinhal cerebral por teste de neutralização",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus neutralizing antibody [Titer] in Cerebral spinal fluid by Neutralization test"
    }]
  },
  {
    "code" : "32361-8",
    "display" : "RNA do vírus do Nilo Ocidental [presença] no soro por NaA com detecção de sonda",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus RNA [Presence] in Serum by NAA with probe detection"
    }]
  },
  {
    "code" : "29569-1",
    "display" : "Anticorpo IgM contra o Vírus do Nilo Ocidental [Presença] no líquido cefalorraquidiano por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgM Ab [Presence] in Cerebral spinal fluid by Immunoassay"
    }]
  },
  {
    "code" : "95674-8",
    "display" : "Anticorpo IgG contra o Vírus Mayaro [Presença] na amostra por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Mayaro virus IgG Ab [Presence] in Specimen by Immunoassay"
    }]
  },
  {
    "code" : "29567-5",
    "display" : "Anticorpo IgM contra o Vírus do Nilo Ocidental [Presença] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgM Ab [Presence] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "33331-0",
    "display" : "Anticorpo IgM contra o Vírus do Nilo Ocidental [Título] no soro",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgM Ab [Titer] in Serum"
    }]
  },
  {
    "code" : "39573-1",
    "display" : "Anticorpo IgM contra o Vírus do Nilo Ocidental [Unidades/volume] no líquido cefalorraquidiano por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgM Ab [Units/volume] in Cerebral spinal fluid by Immunoassay"
    }]
  },
  {
    "code" : "38166-5",
    "display" : "Anticorpo IgM contra o Vírus do Nilo Ocidental [Unidades/volume] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "West Nile virus IgM Ab [Units/volume] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "95689-6",
    "display" : "Anticorpo IgM contra o Vírus Mayaro [Presença] na amostra por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Mayaro virus IgM Ab [Presence] in Specimen by Immunoassay"
    }]
  },
  {
    "code" : "22827-0",
    "display" : "Subtipo do Vírus Influenza A [Identificador] na amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Influenza virus A subtype [Identifier] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "24015-0",
    "display" : "Antígeno do Vírus da Influenza A+B [Presença] na amostra",
    "designation" : [{
      "language" : "en",
      "value" : "Influenza virus A+B Ag [Presence] in Specimen"
    }]
  },
  {
    "code" : "5867-7",
    "display" : "Vírus da Influenza B Antígeno [Presença] na amostra por imunofluorescência",
    "designation" : [{
      "language" : "en",
      "value" : "Influenza virus B Ag [Presence] in Specimen by Immunofluorescence"
    }]
  },
  {
    "code" : "5863-6",
    "display" : "Vírus da Influenza A Antígeno [Presença] na amostra por imunofluorescência",
    "designation" : [{
      "language" : "en",
      "value" : "Influenza virus A Ag [Presence] in Specimen by Immunofluorescence"
    }]
  },
  {
    "code" : "92141-1",
    "display" : "RNA do Vírus da Influenza B [Presença] em amostra do sistema Respiratório por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Influenza virus B RNA [Presence] in Respiratory system specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "92142-9",
    "display" : "RNA do Vírus da Influenza A [Presença] em amostra do sistema Respiratório por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Influenza virus A RNA [Presence] in Respiratory system specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "80382-5",
    "display" : "Antígeno do Vírus da Influenza A [Presença] em amostra das vias respiratórias superiores por imunoensaio rápido",
    "designation" : [{
      "language" : "en",
      "value" : "Influenza virus A Ag [Presence] in Upper respiratory specimen by Rapid immunoassay"
    }]
  },
  {
    "code" : "80383-3",
    "display" : "Vírus da Influenza B Antígeno [Presença] em amostra das vias respiratórias superiores por imunoensaio rápido",
    "designation" : [{
      "language" : "en",
      "value" : "Influenza virus B Ag [Presence] in Upper respiratory specimen by Rapid immunoassay"
    }]
  },
  {
    "code" : "24116-6",
    "display" : "Anticorpo IgM contra o Vírus da Rubéola [Presença] no soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Rubella virus IgM Ab [Presence] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "5335-5",
    "display" : "Anticorpo IgM contra o Vírus da Rubéola [unidades/volume] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Rubella virus IgM Ab [Units/volume] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "40667-8",
    "display" : "Anticorpo IgG contra o Vírus da Rubéola [Presença] no soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Rubella virus IgG Ab [Presence] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "5334-8",
    "display" : "Anticorpo IgG contra o Vírus da Rubéola [Unidades/volume] no soro ou plasma por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Rubella virus IgG Ab [Units/volume] in Serum or Plasma by Immunoassay"
    }]
  },
  {
    "code" : "52986-7",
    "display" : "Avidez do anticorpo IgG contra o Vírus da Rubéola [Relação] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Rubella virus IgG Ab avidity [Ratio] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "54091-4",
    "display" : "RNA do Vírus da Rubéola [Presença] em amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Rubella virus RNA [Presence] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "22498-0",
    "display" : "Anticorpo contra o Vírus do Sarampo [Título] no líquido cefalorraquidiano",
    "designation" : [{
      "language" : "en",
      "value" : "Measles virus Ab [Titer] in Cerebral spinal fluid"
    }]
  },
  {
    "code" : "60422-3",
    "display" : "Genótipo do Vírus do Sarampo [Identificador] na amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Measles virus genotype [Identifier] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "5244-9",
    "display" : "Anticorpo IgG contra o Vírus do Sarampo [Unidades/volume] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Measles virus IgG Ab [Units/volume] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "35276-5",
    "display" : "Anticorpo IgM contra o Vírus do Sarampo [Presença] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Measles virus IgM Ab [Presence] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "25421-9",
    "display" : "Anticorpo IgM contra o Vírus do Sarampo [Unidades/volume] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Measles virus IgM Ab [Units/volume] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "48508-6",
    "display" : "RNA do Vírus do Sarampo [Presença] na amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Measles virus RNA [Presence] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "35275-7",
    "display" : "Anticorpo IgG contra o Vírus do Sarampo [Presença] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Measles virus IgG Ab [Presence] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "15410-4",
    "display" : "Anticorpo IgG contra o Vírus Varicela Zoster [Presença] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Varicella zoster virus IgG Ab [Presence] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "5403-1",
    "display" : "Anticorpo IgG contra o Vírus Varicela Zoster [unidades/volume] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Varicella zoster virus IgG Ab [Units/volume] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "29662-4",
    "display" : "Anticorpo IgM contra o Vírus Varicela Zoster [Presença] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Varicella zoster virus IgM Ab [Presence] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "5404-9",
    "display" : "Anticorpo IgM contra o Vírus Varicela Zoster [unidades/volume] no soro por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Varicella zoster virus IgM Ab [Units/volume] in Serum by Immunoassay"
    }]
  },
  {
    "code" : "49451-8",
    "display" : "DNA do Vírus Varicela Zoster [#/volume] (carga viral) na amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Varicella zoster virus DNA [#/volume] (viral load) in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "11483-5",
    "display" : "DNA do Vírus Varicela Zoster [Presença] na amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Varicella zoster virus DNA [Presence] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "104459-3",
    "display" : "Anticorpo IgG contra o Vírus Varicela Zoster [Presença] no líquido cefalorraquidiano por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Varicella zoster virus IgG Ab [Presence] in Cerebral spinal fluid by Immunoassay"
    }]
  },
  {
    "code" : "17764-2",
    "display" : "Anticorpo IgG contra o Vírus Varicela Zoster [Unidades/volume] no líquido cefalorraquidiano",
    "designation" : [{
      "language" : "en",
      "value" : "Varicella zoster virus IgG Ab [Units/volume] in Cerebral spinal fluid"
    }]
  },
  {
    "code" : "69930-6",
    "display" : "Anticorpo IgM contra o Vírus Varicela Zoster [Presença] no líquido cefalorraquidiano por imunoensaio",
    "designation" : [{
      "language" : "en",
      "value" : "Varicella zoster virus IgM Ab [Presence] in Cerebral spinal fluid by Immunoassay"
    }]
  },
  {
    "code" : "31695-0",
    "display" : "Anticorpo IgM contra o Vírus Varicela Zoster [Unidades/volume] no líquido cefalorraquidiano",
    "designation" : [{
      "language" : "en",
      "value" : "Varicella zoster virus IgM Ab [Units/volume] in Cerebral spinal fluid"
    }]
  },
  {
    "code" : "5877-6",
    "display" : "Vírus Sincicial Respiratório Antígeno [Presença] em amostra por imunofluorescência",
    "designation" : [{
      "language" : "en",
      "value" : "Respiratory syncytial virus Ag [Presence] in Specimen by Immunofluorescence"
    }]
  },
  {
    "code" : "72885-7",
    "display" : "Antígeno do Vírus Sincicial Respiratório [Presença] na nasofaringe por imunoensaio rápido",
    "designation" : [{
      "language" : "en",
      "value" : "Respiratory syncytial virus Ag [Presence] in Nasopharynx by Rapid immunoassay"
    }]
  },
  {
    "code" : "40988-8",
    "display" : "RNA do Vírus Sincicial Respiratório [Presença] na amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Respiratory syncytial virus RNA [Presence] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "30075-6",
    "display" : "RNA do Vírus Sincicial Respiratório A [Presença] na amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Respiratory syncytial virus A RNA [Presence] in Specimen by NAA with probe detection"
    }]
  },
  {
    "code" : "30076-4",
    "display" : "RNA do Vírus Sincicial Respiratório B [Presença] na amostra por amplificação de ácidos nucleicos com detecção por sonda",
    "designation" : [{
      "language" : "en",
      "value" : "Respiratory syncytial virus B RNA [Presence] in Specimen by NAA with probe detection"
    }]
  }]
}

```
